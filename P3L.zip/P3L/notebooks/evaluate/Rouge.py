import json
from rouge_chinese import Rouge  # 改用专门支持中文的rouge-chinese
import nltk
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction

# 下载 nltk 所需的数据
# nltk.download('punkt')

with open("pred_values.json", "r", encoding="utf-8") as f:
    data = json.load(f)

with open("response.jsonl", "r", encoding="utf-8") as f:
    response_dict = [json.loads(line) for line in f]

true_values = []
gen_values = []
for row in response_dict:
    id = row['id']
    result = row['result']
    target = data[id]
    true_values.append(target['target_patent']['abs'])
    gen_values.append(result)

# 按字分词函数
def char_tokenize(text):
    return list(text)  # 直接按字符拆分

rouge = Rouge()
rouge_scores = []
bleu_scores = []
smooth = SmoothingFunction().method1  # BLEU平滑函数

for true_text, gen_text in zip(true_values, gen_values):
    # 按字分词
    true_chars = char_tokenize(true_text)
    gen_chars = char_tokenize(gen_text)
    
    # 计算ROUGE（需将分词结果用空格连接）
    try:
        scores = rouge.get_scores(' '.join(gen_chars), ' '.join(true_chars))
        rouge_scores.append(scores[0])
    except ValueError as e:
        print(f"ROUGE计算错误: {e} | 参考文本: {true_text}")
    
    # 计算BLEU
    try:
        bleu_score = sentence_bleu([true_chars], gen_chars, smoothing_function=smooth)
        bleu_scores.append(bleu_score)
    except ZeroDivisionError:
        print(f"BLEU零除错误 | 参考文本: {true_text}")

# 汇总分数
avg_rouge_1_f1 = sum(s['rouge-1']['f'] for s in rouge_scores) / len(rouge_scores) if rouge_scores else 0
avg_rouge_2_f1 = sum(s['rouge-2']['f'] for s in rouge_scores) / len(rouge_scores) if rouge_scores else 0
avg_rouge_l_f1 = sum(s['rouge-l']['f'] for s in rouge_scores) / len(rouge_scores) if rouge_scores else 0
avg_bleu = sum(bleu_scores) / len(bleu_scores) if bleu_scores else 0

print("平均ROUGE-1 F1:", round(avg_rouge_1_f1, 4))
print("平均ROUGE-2 F1:", round(avg_rouge_2_f1, 4))
print("平均ROUGE-L F1:", round(avg_rouge_l_f1, 4))
print("平均BLEU:", round(avg_bleu, 4))