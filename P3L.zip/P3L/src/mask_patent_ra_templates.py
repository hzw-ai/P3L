
all_tasks = {}


# =====================================================
# Task Subgroup 2 -- Sequential -- 11 Prompts
# =====================================================

task_subgroup_2 = {}

template = {}

template['source'] = "Below is a sequence of similar patents arranged in chronological order: {} , what are the keywords for the next patent in this sequence?"
template['target'] = "<extra_id_0> {} <extra_id_1>"
template['task'] = "sequential"
template['source_argc'] = 2
template['source_argv'] = ['user_id', 'purchase_history']
template['target_argc'] = 1
template['target_argv'] = ['item_id']
template['id'] = "2-1"

task_subgroup_2["2-1"] = template


template = {}

template['source'] = "Here is a chronological list of similar patents: {} , which keywords predict the next patent?"
template['target'] = "<extra_id_0> {} <extra_id_1>"
template['task'] = "sequential"
template['source_argc'] = 2
template['source_argv'] = ['user_desc', 'purchase_history']
template['target_argc'] = 1
template['target_argv'] = ['item_id']
template['id'] = "2-2"

task_subgroup_2["2-2"] = template


template = {}

template['source'] = "There is a chronological sequence of similar patents: {} , and what is the keyword of the next patent?"
template['target'] = "<extra_id_0> {} <extra_id_1>"
template['task'] = "sequential"
template['source_argc'] = 2
template['source_argv'] = ['user_id', 'purchase_history']
template['target_argc'] = 1
template['target_argv'] = ['item_id']
template['id'] = "2-3"

task_subgroup_2["2-3"] = template


template = {}


template['source'] = "The sequence of similar patents sorted by time is: {} and their next patent keyword is?"
template['target'] = "<extra_id_0> {} <extra_id_1>"
template['task'] = "sequential"
template['source_argc'] = 2
template['source_argv'] = ['user_id', 'purchase_history']
template['target_argc'] = 1
template['target_argv'] = ['item_id']
template['id'] = "2-4"

task_subgroup_2["2-4"] = template


template = {}

template['source'] = "Based on this chronological sequence of similar patents: {} , what is expected to be the next patent keyword?"
template['target'] = "<extra_id_0> {} <extra_id_1>"
template['task'] = "sequential"
template['source_argc'] = 2
template['source_argv'] = ['user_desc', 'purchase_history']
template['target_argc'] = 1
template['target_argv'] = ['item_id']
template['id'] = "2-5"

task_subgroup_2["2-5"] = template


template = {}

template['source'] = "The sequence of similar patents sorted by time in the past is: {} , and the current patent keyword is?"
template['target'] = "<extra_id_0> {} <extra_id_1>"
template['task'] = "sequential"
template['source_argc'] = 2
template['source_argv'] = ['user_id', 'purchase_history']
template['target_argc'] = 1
template['target_argv'] = ['item_id']
template['id'] = "2-6"

task_subgroup_2["2-6"] = template

all_tasks['sequential'] =  task_subgroup_2