import argparse
import random

import numpy as np
import torch

import pprint
import yaml


def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')


def is_interactive():
    import __main__ as main
    return not hasattr(main, '__file__')


def get_optimizer(optim, verbose=False):
    # Bind the optimizer
    if optim == 'rms':
        if verbose:
            print("Optimizer: Using RMSProp")
        optimizer = torch.optim.RMSprop
    elif optim == 'adam':
        if verbose:
            print("Optimizer: Using Adam")
        optimizer = torch.optim.Adam
    elif optim == 'adamw':
        if verbose:
            print("Optimizer: Using AdamW")
        optimizer = 'adamw'
    elif optim == 'adamax':
        if verbose:
            print("Optimizer: Using Adamax")
        optimizer = torch.optim.Adamax
    elif optim == 'sgd':
        if verbose:
            print("Optimizer: SGD")
        optimizer = torch.optim.SGD
    else:
        assert False, "Please add your optimizer %s in the list." % optim

    return optimizer


def parse_args(parse=True, **optional_kwargs):
    parser = argparse.ArgumentParser()

    parser.add_argument('--seed', type=int, default=2023, help='random seed')

    # Data Splits
    parser.add_argument("--data_url", default='/home/tao/demo/KP4SR/data')
    parser.add_argument("--train", default='books')
    parser.add_argument("--valid", default='books')
    parser.add_argument("--test", default=None)
    parser.add_argument('--test_only', action='store_true')

    parser.add_argument('--submit', action='store_true')

    # Checkpoint
    parser.add_argument('--log_url', type=str, default='/home/tao/demo/KP4SR/log')
    parser.add_argument('--load', type=str, default=None, help='Load the model (usually the fine-tuned model).')
    parser.add_argument('--train_url', type=str, default='/home/tao/demo/KP4SR/',
                        help='Load the model (usually the fine-tuned model).')
    parser.add_argument('--from_scratch', action='store_true')

    # CPU/GPU
    parser.add_argument("--multiGPU", action='store_const', default=True, const=True)
    parser.add_argument('--fp16', action='store_false')
    parser.add_argument("--distributed", action='store_false')
    parser.add_argument("--num_workers", default=2, type=int)
    parser.add_argument('--local_rank', '--local-rank', type=int, default=0)

    # Model Config
    parser.add_argument('--backbone', type=str, default='models/t5-small')
    parser.add_argument('--tokenizer', type=str, default='p5')
    parser.add_argument('--whole_word_embed', action='store_false')

    parser.add_argument('--max_text_length', type=int, default=512)

    # Training
    parser.add_argument('--batch_size', type=int, default=64)
    parser.add_argument('--valid_batch_size', type=int, default=None)
    parser.add_argument('--optim', default='adamw')
    parser.add_argument('--warmup_ratio', type=float, default=0.05)
    parser.add_argument('--weight_decay', type=float, default=0.01)
    parser.add_argument('--clip_grad_norm', type=float, default=1.0)
    parser.add_argument('--gradient_accumulation_steps', type=int, default=1)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--adam_eps', type=float, default=1e-6)
    parser.add_argument('--adam_beta1', type=float, default=0.9)
    parser.add_argument('--adam_beta2', type=float, default=0.999)
    parser.add_argument('--epoch', type=int, default=100)
    parser.add_argument('--dropout', type=float, default=0.1)

    parser.add_argument("--losses", default='sequential', type=str)
    parser.add_argument('--log_train_accuracy', action='store_true')

    parser.add_argument('--eval_interval', type=int, default=5)
    parser.add_argument('--degree', type=int, default=8, help='relation number of kg')
    parser.add_argument('--hop_num', type=int, default=2, help='number of kg hop')
    parser.add_argument('--max_items', type=int, default=5, help='number of items')

    parser.add_argument("--test_random", action='store_false')
    # parser.add_argument("--tree_mask", action='store_true')
    parser.add_argument("--cross_mask", action='store_true')
    parser.add_argument("--tree_mask",  action='store_true')
    parser.add_argument("--keyword_mask",  action='store_true')
    parser.add_argument("--similarity_mask",  action='store_true')
    parser.add_argument("--similarity_sug", action='store_true')

    # Inference
    parser.add_argument('--num_beams', type=int, default=1)
    parser.add_argument('--gen_max_length', type=int, default=64)

    # Data
    parser.add_argument('--do_lower_case', action='store_true')

    # Etc.
    parser.add_argument('--prefix', type=str, default='')
    parser.add_argument('--comment', type=str, default='')
    parser.add_argument("--dry", action='store_true')

    parser.add_argument("--gpu_ids", type=str, default='-1', help='gpu ids: e.g. 0  0,1,2, 0,2. use -1 for CPU')

    # Parse the arguments.
    if parse:
        args = parser.parse_args()
    # For interative engironmnet (ex. jupyter)
    else:
        # args = parser.parse_known_args()[0]
        args = parser.parse_args(args=[])

    # Namespace => Dictionary
    kwargs = vars(args)
    kwargs.update(optional_kwargs)

    args = Config(**kwargs)

    # Bind optimizer class.
    verbose = False
    args.optimizer = get_optimizer(args.optim, verbose=verbose)

    # Set seeds
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)

    return args


class Config(object):
    def __init__(self, **kwargs):
        """Configuration Class: set kwargs as class attributes with setattr"""
        for k, v in kwargs.items():
            setattr(self, k, v)

    @property
    def config_str(self):
        return pprint.pformat(self.__dict__)

    def __repr__(self):
        """Pretty-print configurations in alphabetical order"""
        config_str = 'Configurations\n'
        config_str += self.config_str
        return config_str

    def save(self, path):
        with open(path, 'w') as f:
            yaml.dump(self.__dict__, f, default_flow_style=False)

    @classmethod
    def load(cls, path):
        with open(path, 'r') as f:
            kwargs = yaml.load(f)

        return Config(**kwargs)


if __name__ == '__main__':
    args = parse_args(True)
