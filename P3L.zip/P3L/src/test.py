import torch
from datetime import datetime
import json
import glob
import time
import sys
import re

from pathlib import Path

# 获取脚本的父目录
script_dir = Path(__file__).resolve().parent

# 将父目录添加到 sys.path
sys.path.append(str(script_dir.parent))

from notebooks.evaluate.metrics4rec import evaluate_all



def convert_json_key(param_dict):
    """
    json.dump不支持key是int的dict，在编码存储的时候会把所有的int型key写成str类型的
    所以在读取json文件后，用本方法将所有的被解码成str的int型key还原成int
    """
    new_dict = dict()
    for key, value in param_dict.items():
        # print(key)
        if isinstance(value, (dict,)):
            res_dict = convert_json_key(value)
            try:
                new_key = key
                new_dict[new_key] = res_dict
            except:
                new_dict[key] = res_dict
        else:
            try:
                new_key = key
                new_dict[new_key] = value
            except:
                new_dict[key] = value

    return new_dict


with open('../data/patent_lm/text2keyid.json', 'r', encoding="utf-8") as f:
    keys_data = json.load(f)

keys = []
for item in keys_data:
    key = keys_data[item].replace("m.", "")
    keys.append(key)

temps = glob.glob(f'../results/patent_lm/temp_max_items_5.json')
# temps = glob.glob(f'/home/tao/demo/KP4SR/patent_kg_models/t5-small_2hop_d8_L20_1e-2_mask/temp_0.json')
ui_scores_temp = {}
gt_temp = {}
num = 0
num_1 = 0
for temp_path in temps:
    with open(temp_path, "r") as f:
        temp = json.load(f)
    for idx, item in temp['ui_scores'].items():
        ui_scores_temp[num] = convert_json_key(item)
        num += 1
    for idx, item in temp['gt'].items():
        gt_temp[num_1] = item
        num_1 += 1
print(ui_scores_temp)
print(gt_temp)
# logging.info(gt_temp)
msg, res = evaluate_all(ui_scores_temp, gt_temp, 5)
print(msg)
unique_list = list(set(res['keys']))
rel_num = 0
for item in res['keys']:
    if str(item.strip()) not in keys:
        rel_num += 1
print("1000个专利中的幻觉关键词@5:{}".format(rel_num))
msg, res = evaluate_all(ui_scores_temp, gt_temp, 10)
print(msg)
unique_list = list(set(res['keys']))
rel_num = 0
for item in res['keys']:
    if str(item.strip()) not in keys:
        rel_num += 1
print("1000个专利中的幻觉关键词@10:{}".format(rel_num))
# msg, res = evaluate_all(ui_scores_temp, gt_temp, 15)
# print(msg)

